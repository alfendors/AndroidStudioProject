package ValidationStyle;

public class BASIC {
}
