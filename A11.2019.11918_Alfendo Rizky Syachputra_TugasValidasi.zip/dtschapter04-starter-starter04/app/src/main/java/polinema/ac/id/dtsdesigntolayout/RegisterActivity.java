package polinema.ac.id.dtsdesigntolayout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class RegisterActivity extends AppCompatActivity {

    // Tambahkan variabel di sini

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        // Inisialisasi variabel
    }

    public void postSignUp(View view) {
        // Tambahkan kode untuk proses sign up
    }
}
