package polinema.ac.id.dtsdesigntolayout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ResetPassword<AwesomeValidation> extends AppCompatActivity {

    // Deklarasi EditText
    EditText editTextCode, editTextNewpass, editTextConpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        // Binding EditText
        editTextCode = findViewById(R.id.edt_txt_code);
        editTextNewpass = findViewById(R.id.edt_new_password);
        editTextConpass = findViewById(R.id.edt_confirm_password);

    }
    public void postChangePassword(View view) {
        // Validasi kosong
        if(TextUtils.isEmpty(editTextCode.getText().toString().trim()) ||
                TextUtils.isEmpty(editTextNewpass.getText().toString()) ||
                TextUtils.isEmpty(editTextConpass.getText().toString())) {
            Toast.makeText(view.getContext(), "Tidak boleh ada yang kosong",
                    Toast.LENGTH_LONG).show();
        }
        // Cek inputan new dan confirm
        else if (!editTextNewpass.getText().toString().equals(editTextConpass.getText().toString())) {
            Toast.makeText(view.getContext(), "Password tidak sama!", Toast.LENGTH_SHORT).show();
        }
        else {
            Intent i = new Intent(ResetPassword.this, SuccessActivity.class);
            startActivity(i);
        }
    }
}


