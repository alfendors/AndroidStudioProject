package polinema.ac.id.dtschapter03_starter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class WelcomeSlideCalender_11918 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_slide_calender11918);
    }
    public void clickGetStarted (View view){
        Intent i = new Intent(WelcomeSlideCalender_11918. this, WelcomeSlideSuperhero_11918.class);
        startActivity(i);

    }

    public void clickLogin(View view){
        Intent i =new Intent(WelcomeSlideCalender_11918.this, WelcomeBack_11918.class);
        startActivity(i);
    }
}