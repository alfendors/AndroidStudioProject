package polinema.ac.id.dtschapter03_starter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ForgotPassword_11918 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password11918);
    }
    public void postSendRequest(View view){
        Intent i = new Intent(ForgotPassword_11918.this, ResetPassword_11918.class);
        startActivity(i);
    }
}
